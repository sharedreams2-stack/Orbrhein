// Oberjein arpeggiator: sample-timed step sequencer over the held notes.
// Audio-thread only (except the lane atomics, which the UI may read/write). No allocation.
//
// Model:  held notes -> pattern walker (13 modes, octave range) -> per-stage lane
//         (64 stages: pitch/vel/gate/prob/ratchet/on/tie/mod) -> scale shift/quantize
//         -> chord stack -> strum -> ratchet -> scheduled note-on / note-off.
// The "random advanced" generator and "evolve" mutate the lane with the same controls.
#pragma once
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>

#include "params.h"

namespace ob {

constexpr int kLaneSteps = 64;

// Lane ids (also the bit index in the lock mask). Keep in sync with Lane.kt.
enum LaneId : int { L_PITCH = 0, L_VEL, L_GATE, L_PROB, L_RATCH, L_ON, L_MOD, L_COUNT };

// Counts of the enumerated params (normalized value = index / (count - 1)). Keep in sync with Names in Params.kt.
constexpr int kModes = 13, kRates = 10, kChords = 15, kScales = 15, kStrumDirs = 4;

struct Step {
    int pitch = 0;     // scale degrees, -48..48
    int vel = 100;     // 0..127
    int gate = 100;    // 0..127, 100 = x1.0
    int prob = 100;    // 0..100
    int ratch = 1;     // 1..8 (1 = use global ratchet)
    bool on = true;
    bool tie = false;
    int mod = 64;      // 0..127, 64 = 0.0 on the "Lane mod" source
};

// bits: pitch+64 [0..6], vel [7..13], gate [14..20], prob [21..27], ratch-1 [28..30], on [31], tie [32], mod [33..39]
inline uint64_t packStep(const Step& s) {
    auto c = [](int v, int lo, int hi) { return static_cast<uint64_t>(std::clamp(v, lo, hi)); };
    return c(s.pitch + 64, 16, 112) | (c(s.vel, 0, 127) << 7) | (c(s.gate, 0, 127) << 14) |
           (c(s.prob, 0, 100) << 21) | ((c(s.ratch, 1, 8) - 1) << 28) |
           (static_cast<uint64_t>(s.on) << 31) | (static_cast<uint64_t>(s.tie) << 32) | (c(s.mod, 0, 127) << 33);
}
inline Step unpackStep(uint64_t v) {
    Step s;
    s.pitch = static_cast<int>(v & 127) - 64;
    s.vel = static_cast<int>((v >> 7) & 127);
    s.gate = static_cast<int>((v >> 14) & 127);
    s.prob = std::min(100, static_cast<int>((v >> 21) & 127));
    s.ratch = static_cast<int>((v >> 28) & 7) + 1;
    s.on = ((v >> 31) & 1) != 0;
    s.tie = ((v >> 32) & 1) != 0;
    s.mod = static_cast<int>((v >> 33) & 127);
    return s;
}

struct ScaleDef { int n; int iv[12]; };
constexpr ScaleDef kScaleTable[kScales] = {
    {12, {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}},  // Chromatic
    {7, {0, 2, 4, 5, 7, 9, 11}},                   // Major
    {7, {0, 2, 3, 5, 7, 8, 10}},                   // Natural minor
    {7, {0, 2, 3, 5, 7, 8, 11}},                   // Harmonic minor
    {7, {0, 2, 3, 5, 7, 9, 11}},                   // Melodic minor
    {7, {0, 2, 3, 5, 7, 9, 10}},                   // Dorian
    {7, {0, 1, 3, 5, 7, 8, 10}},                   // Phrygian
    {7, {0, 2, 4, 6, 7, 9, 11}},                   // Lydian
    {7, {0, 2, 4, 5, 7, 9, 10}},                   // Mixolydian
    {7, {0, 1, 3, 5, 6, 8, 10}},                   // Locrian
    {5, {0, 2, 4, 7, 9}},                          // Pentatonic major
    {5, {0, 3, 5, 7, 10}},                         // Pentatonic minor
    {6, {0, 3, 5, 6, 7, 10}},                      // Blues
    {6, {0, 2, 4, 6, 8, 10}},                      // Whole tone
    {8, {0, 2, 3, 5, 6, 8, 9, 11}},                // Diminished (W-H)
};

// Fixed chords as semitone stacks (index = ARP_CHORD). 12..14 are diatonic (scale degrees 0,2,4[,6[,8]]).
struct ChordDef { int n; int iv[5]; };
constexpr ChordDef kChordTable[kChords] = {
    {1, {0}}, {2, {0, 12}}, {2, {0, 7}}, {3, {0, 7, 12}}, {3, {0, 4, 7}}, {3, {0, 3, 7}}, {3, {0, 2, 7}},
    {3, {0, 5, 7}}, {4, {0, 4, 7, 11}}, {4, {0, 3, 7, 10}}, {4, {0, 4, 7, 10}}, {4, {0, 4, 7, 14}},
    {3, {0, 2, 4}}, {4, {0, 2, 4, 6}}, {5, {0, 2, 4, 6, 8}},
};

// Division in quarter-note beats, fastest last. ticks24 = beats * 24 (integral).
constexpr float kRateBeats[kRates] = {2.0f, 1.0f, 0.75f, 0.5f, 0.375f, 1.0f / 3.0f, 0.25f, 1.0f / 6.0f, 0.125f, 1.0f / 12.0f};
constexpr int kRateTicks[kRates] = {48, 24, 18, 12, 9, 8, 6, 4, 3, 2};

inline int floorDiv(int a, int b) { int q = a / b; return (a % b != 0 && ((a < 0) != (b < 0))) ? q - 1 : q; }
inline int idxOf(float v, int count) { return std::clamp(static_cast<int>(std::lround(v * (count - 1))), 0, count - 1); }

// Interface the arp uses to reach the synth (implemented by Synth).
struct ArpHost {
    virtual ~ArpHost() = default;
    virtual float p(int id) const = 0;                 // modulated parameter value (0..1)
    virtual void arpNoteOn(int note, float vel) = 0;
    virtual void arpNoteOff(int note) = 0;
    virtual void arpSources(float rnd, float laneMod) = 0;  // feeds the mod matrix (bipolar -1..1)
};

class Arp {
public:
    explicit Arp(ArpHost* host) : h_(host) {
        Step d; const uint64_t v = packStep(d);
        for (auto& l : lane_) l.store(v);
    }

    void setSampleRate(float sr) { sr_ = sr; }

    // ---- lane (any thread) ----
    uint64_t lane(int i) const { return lane_[std::clamp(i, 0, kLaneSteps - 1)].load(std::memory_order_relaxed); }
    void setLane(int i, uint64_t v) { lane_[std::clamp(i, 0, kLaneSteps - 1)].store(v, std::memory_order_relaxed); }
    int playhead() const { return playhead_.load(std::memory_order_relaxed); }

    // ---- held notes (audio thread) ----
    void add(int note, float /*vel*/) {
        if (cnt_ >= 128) return;
        for (int i = 0; i < cnt_; ++i) if (ord_[i] == note) return;
        if (cnt_ == 0) restart();
        ord_[cnt_++] = note;
    }
    void remove(int note) {
        int w = 0;
        for (int i = 0; i < cnt_; ++i) if (ord_[i] != note) ord_[w++] = ord_[i];
        cnt_ = w;
    }
    void clearNotes() { cnt_ = 0; }

    // Silence everything the arp is sounding (arp turned off, panic).
    void stop() {
        for (int n = 0; n < 128; ++n) if (snd_[n] > 0) { snd_[n] = 0; h_->arpNoteOff(n); }
        nEv_ = 0; hasPending_ = false;
        playhead_.store(-1, std::memory_order_relaxed);
    }

    // ---- external clock (audio thread) ----
    void extTick() {
        if (extStopped_) return;
        if (lastTickTime_ > 0.0) {
            const float d = static_cast<float>(time_ - lastTickTime_);
            if (d > 0.0f) tickLen_ = tickLen_ <= 0.0f ? d : tickLen_ * 0.9f + d * 0.1f;
        }
        lastTickTime_ = time_;
        const int tps = kRateTicks[idxOf(h_->p(P_ARP_RATE), kRates)];
        if (tickCount_ % tps == 0 && cnt_ > 0) {
            const double delay = parity_ ? h_->p(P_ARP_SWING) * 0.4 * tps * std::max(tickLen_, 1.0f) : 0.0;
            parity_ ^= 1;
            if (delay <= 0.0) fire(time_);
            else { pendingDue_ = time_ + delay; hasPending_ = true; }
        }
        ++tickCount_;
    }
    void extStart(bool reset) {
        extStopped_ = false;
        if (reset) { tickCount_ = 0; restart(); }
    }
    void extStop() { extStopped_ = true; stop(); }

    // ---- control-rate tick (audio thread) ----
    void tick(int samples) {
        time_ += samples;
        processEvents();
        const bool ext = h_->p(P_ARP_CLOCK) > 0.5f;
        if (cnt_ == 0) {
            nominal_ = time_;
            hasPending_ = false;
            if (nEv_ == 0) playhead_.store(-1, std::memory_order_relaxed);
            return;
        }
        if (ext) {
            if (hasPending_ && time_ >= pendingDue_) { hasPending_ = false; fire(pendingDue_); }
            return;
        }
        for (int guard = 0; guard < 8; ++guard) {
            const double len = stepLen();
            const double due = nominal_ + (parity_ ? h_->p(P_ARP_SWING) * 0.4 * len : 0.0);
            if (time_ < due) break;
            fire(due);
            nominal_ += len;
            parity_ ^= 1;
        }
    }

    // ---- random lane generator (audio thread) ----
    void generate(uint32_t seed) {
        rng_ = seed ? seed : 0x9E3779B9u;
        const int lock = lockMask();
        for (int i = 0; i < kLaneSteps; ++i) {
            Step cur = unpackStep(lane_[i].load(std::memory_order_relaxed));
            const Step fresh = freshStep();
            if (!(lock & (1 << L_PITCH))) cur.pitch = fresh.pitch;
            if (!(lock & (1 << L_VEL))) cur.vel = fresh.vel;
            if (!(lock & (1 << L_GATE))) cur.gate = fresh.gate;
            if (!(lock & (1 << L_PROB))) cur.prob = fresh.prob;
            if (!(lock & (1 << L_RATCH))) cur.ratch = fresh.ratch;
            if (!(lock & (1 << L_ON))) { cur.on = fresh.on; cur.tie = fresh.tie; }
            if (!(lock & (1 << L_MOD))) cur.mod = fresh.mod;
            lane_[i].store(packStep(cur), std::memory_order_relaxed);
        }
    }

private:
    struct Ev { double t; int note; float vel; bool on; };

    float rnd() {
        rng_ ^= rng_ << 13; rng_ ^= rng_ >> 17; rng_ ^= rng_ << 5;
        return static_cast<float>(rng_ >> 8) / 16777216.0f;
    }
    int rndInt(int n) { return std::min(n - 1, static_cast<int>(rnd() * n)); }
    int lockMask() const { return static_cast<int>(std::lround(h_->p(P_RND_LOCK) * 127.0f)); }
    int lenParam() const { return 1 + static_cast<int>(std::lround(h_->p(P_ARP_LEN) * 63.0f)); }

    void restart() {
        step_ = 0; walker_ = 0; wk_ = 0; cycles_ = 0; shiftAcc_ = 0; parity_ = 0; strumFlip_ = false;
        nominal_ = time_; hasPending_ = false;
    }

    double stepLen() const {
        const bool ext = h_->p(P_ARP_CLOCK) > 0.5f;
        if (ext && tickLen_ > 0.0f) return static_cast<double>(kRateTicks[idxOf(h_->p(P_ARP_RATE), kRates)]) * tickLen_;
        const double bpm = 30.0 + 270.0 * h_->p(P_ARP_BPM);
        return sr_ * 60.0 / bpm * kRateBeats[idxOf(h_->p(P_ARP_RATE), kRates)];
    }

    // ---- scales ----
    const ScaleDef& scale() const {
        int s = idxOf(h_->p(P_ARP_SCALE), kScales);
        return kScaleTable[s];
    }
    int rootPc() const { return idxOf(h_->p(P_ARP_ROOT), 12); }

    static int toDegree(int note, const ScaleDef& sc, int root) {
        const int rel = note - root;
        const int oct = floorDiv(rel, 12);
        const int pc = rel - 12 * oct;
        int best = 0, bd = 99;
        for (int k = 0; k < sc.n; ++k) { const int d = std::abs(sc.iv[k] - pc); if (d < bd) { bd = d; best = k; } }
        if (std::abs(12 - pc) < bd) best = sc.n;
        return oct * sc.n + best;
    }
    static int toNote(int deg, const ScaleDef& sc, int root) {
        const int oct = floorDiv(deg, sc.n);
        const int k = deg - oct * sc.n;
        return root + 12 * oct + sc.iv[k];
    }

    // ---- pattern walker ----
    int patternIndex(int mode, int pos, int n) {
        if (n <= 1) return 0;
        auto upDown = [&](int p) { const int per = std::max(1, 2 * n - 2); p %= per; return p < n ? p : per - p; };
        auto converge = [&](int k) { return (k % 2 == 0) ? k / 2 : n - 1 - k / 2; };
        switch (mode) {
            case 0: return pos % n;                          // Up
            case 1: return n - 1 - pos % n;                  // Down
            case 2: return upDown(pos);                      // Up-Down (no repeated ends)
            case 3: return n - 1 - upDown(pos);              // Down-Up
            case 4: { const int p = pos % (2 * n); return p < n ? p : 2 * n - 1 - p; }  // Up&Down (ends repeat)
            case 5: return converge(pos % n);                // Converge
            case 6: return converge(n - 1 - pos % n);        // Diverge
            case 7: return pos % n;                          // Order (pool is in press order)
            case 8: return rndInt(n);                        // Random
            case 9: {                                        // Walk
                wk_ = std::clamp(wk_ + (rnd() < 0.5f ? -1 : 1), 0, n - 1);
                return wk_;
            }
            case 10: { const int p = pos % (2 * (n - 1)); return p % 2 == 0 ? 0 : p / 2 + 1; }      // Thumb up
            case 11: { const int p = pos % (2 * (n - 1)); return p % 2 == 0 ? p / 2 : n - 1; }      // Pinky up
            default: return 0;
        }
    }

    int buildPool(int mode) {
        int base[128];
        const int n = cnt_;
        for (int i = 0; i < n; ++i) base[i] = ord_[i];
        if (mode != 7) std::sort(base, base + n);
        const int octs = 1 + std::clamp(static_cast<int>(std::lround(h_->p(P_ARP_OCT) * 3.0f)), 0, 3);
        int pn = 0;
        for (int o = 0; o < octs; ++o)
            for (int i = 0; i < n; ++i) {
                const int v = base[i] + 12 * o;
                if (v <= 127 && pn < static_cast<int>(pool_.size())) pool_[pn++] = v;
            }
        return pn;
    }

    // ---- one step ----
    void fire(double due) {
        const int len = lenParam();
        const int idx = step_ % len;
        const Step s = unpackStep(lane_[idx].load(std::memory_order_relaxed));
        playhead_.store(idx, std::memory_order_relaxed);
        const float r = rnd();
        h_->arpSources(r * 2.0f - 1.0f, (s.mod - 64) / 63.5f);

        ++step_;
        const bool cycleEnd = (idx == len - 1);

        const float probG = h_->p(P_ARP_PROB);
        bool play = s.on && cnt_ > 0 && rnd() < probG * (static_cast<float>(s.prob) / 100.0f);
        if (play) schedule(due, s);
        if (cycleEnd) onCycleEnd(len);
    }

    void schedule(double due, const Step& s) {
        const int mode = idxOf(h_->p(P_ARP_MODE), kModes);
        const int pn = buildPool(mode);
        if (pn == 0) return;

        // 1) pick base notes
        int base[16]; int nb = 0;
        if (mode == 12) {                                   // Chord mode: the whole pool at once
            for (int i = 0; i < pn && nb < 16; ++i) base[nb++] = pool_[i];
        } else {
            base[nb++] = pool_[patternIndex(mode, walker_, pn)];
            ++walker_;
        }

        // 2) scale shift / quantize
        const ScaleDef& sc = scale();
        const int root = rootPc();
        const bool quant = h_->p(P_ARP_QUANT) > 0.5f && sc.n != 12;
        const int shift = static_cast<int>(std::lround((h_->p(P_ARP_SHIFT) - 0.5f) * 24.0f));
        const int deg = s.pitch + shift + shiftAcc_;
        for (int i = 0; i < nb; ++i) {
            if (quant || deg != 0) {
                const int d = toDegree(base[i], sc, root);
                base[i] = toNote(d + deg, sc, root);
            }
        }

        // 3) chord stack
        int notes[48]; int m = 0;
        const int ct = idxOf(h_->p(P_ARP_CHORD), kChords);
        const ScaleDef& dia = (sc.n == 12) ? kScaleTable[1] : sc;
        for (int i = 0; i < nb; ++i) {
            if (ct >= 12) {
                const int d0 = toDegree(base[i], dia, root);
                const ChordDef& cd = kChordTable[ct];
                for (int k = 0; k < cd.n && m < 48; ++k) notes[m++] = toNote(d0 + cd.iv[k], dia, root);
            } else {
                const ChordDef& cd = kChordTable[ct];
                for (int k = 0; k < cd.n && m < 48; ++k) notes[m++] = base[i] + cd.iv[k];
            }
        }
        std::sort(notes, notes + m);
        m = static_cast<int>(std::unique(notes, notes + m) - notes);
        int outN = 0; int out[48];
        for (int i = 0; i < m; ++i) if (notes[i] >= 0 && notes[i] <= 127) out[outN++] = notes[i];
        if (outN == 0) return;

        // 4) strum order + spacing
        const double len = stepLen();
        const int dir = idxOf(h_->p(P_ARP_STRUM_DIR), kStrumDirs);
        bool down = (dir == 1) || (dir == 2 && strumFlip_);
        if (dir == 2) strumFlip_ = !strumFlip_;
        if (dir == 3) for (int i = outN - 1; i > 0; --i) std::swap(out[i], out[rndInt(i + 1)]);
        if (down && dir != 3) std::reverse(out, out + outN);
        const double span = h_->p(P_ARP_STRUM) * len * 0.9;
        const double per = outN > 1 ? span / outN : 0.0;

        // 5) ratchet, gate, velocity
        int ratch = s.ratch;
        if (ratch <= 1) {
            const int g = 1 + static_cast<int>(std::lround(h_->p(P_ARP_RATCH) * 7.0f));
            if (g > 1 && rnd() < h_->p(P_ARP_RATCH_PROB)) ratch = g;
        }
        const double sub = len / ratch;
        const float gateG = 0.05f + 0.95f * h_->p(P_ARP_GATE);
        const double hitLen = s.tie ? len * 1.05 : std::max(0.002 * sr_, sub * std::min(1.5f, gateG * (s.gate / 100.0f)));
        const float human = h_->p(P_ARP_HUMAN);
        const float velGain = 0.5f + h_->p(P_ARP_VEL);

        for (int j = 0; j < ratch; ++j) {
            const double jitter = human > 0.0f ? rnd() * human * 0.12 * len : 0.0;
            for (int k = 0; k < outN; ++k) {
                float v = (s.vel / 127.0f) * velGain * std::max(0.3f, 1.0f - 0.1f * j);
                if (human > 0.0f) v *= 1.0f + (rnd() * 2.0f - 1.0f) * human * 0.25f;
                v = std::clamp(v, 0.05f, 1.0f);
                const double t = due + jitter + j * sub + k * per;
                pushEv({t, out[k], v, true});
                pushEv({t + hitLen, out[k], 0.0f, false});
            }
        }
    }

    void onCycleEnd(int len) {
        ++cycles_;
        const ScaleDef& sc = scale();
        const int per = static_cast<int>(std::lround((h_->p(P_ARP_SHIFT_CYCLE) - 0.5f) * 14.0f));
        if (per != 0) {
            const int lim = 2 * sc.n, span = 2 * lim + 1;
            int v = shiftAcc_ + per + lim;
            v = ((v % span) + span) % span;
            shiftAcc_ = v - lim;
        } else {
            shiftAcc_ = 0;
        }
        if (h_->p(P_EVO_ON) > 0.5f) {
            const int every = 1 + static_cast<int>(std::lround(h_->p(P_EVO_RATE) * 15.0f));
            if (cycles_ % every == 0) mutate(len);
        }
    }

    // ---- random / evolve (same controls) ----
    Step freshStep() {
        Step s;
        const int range = 1 + static_cast<int>(std::lround(h_->p(P_RND_RANGE) * 23.0f));
        const float bias = h_->p(P_RND_BIAS);
        const float uni = rnd() * 2.0f - 1.0f, tri = rnd() + rnd() - 1.0f;
        int deg = static_cast<int>(std::lround((uni + (tri - uni) * bias) * range));
        if (rnd() < h_->p(P_RND_CHORDTONE)) {
            const ScaleDef& sc = scale();
            const int n = (sc.n == 12) ? 7 : sc.n;
            const int tones[3] = {0, std::max(1, (2 * n + 3) / 7), std::max(2, (4 * n + 3) / 7)};
            int best = deg, bd = 1000;
            const int oct = floorDiv(deg, n);
            for (int o = oct - 1; o <= oct + 1; ++o)
                for (int t : tones) { const int c = o * n + t; if (std::abs(c - deg) < bd) { bd = std::abs(c - deg); best = c; } }
            deg = best;
        }
        s.pitch = std::clamp(deg, -48, 48);
        s.vel = std::clamp(static_cast<int>(100 + (rnd() * 2.0f - 1.0f) * h_->p(P_RND_VEL) * 60.0f), 20, 127);
        s.gate = std::clamp(static_cast<int>(100 + (rnd() * 2.0f - 1.0f) * h_->p(P_RND_GATE) * 70.0f), 10, 127);
        s.prob = std::clamp(static_cast<int>(100.0f - rnd() * h_->p(P_RND_PROB) * 80.0f), 15, 100);
        const float rc = h_->p(P_RND_RATCH);
        const float rr = rnd();
        s.ratch = rnd() < rc ? (rr < 0.5f ? 2 : rr < 0.8f ? 3 : 4) : 1;
        s.on = rnd() < h_->p(P_RND_DENSITY);
        s.tie = s.on && rnd() < h_->p(P_RND_TIE);
        s.mod = std::clamp(static_cast<int>(64 + (rnd() * 2.0f - 1.0f) * h_->p(P_RND_MOD) * 63.0f), 0, 127);
        return s;
    }

    void mutate(int len) {
        const float amt = h_->p(P_EVO_AMT);
        if (amt <= 0.0f) return;
        const float keep = h_->p(P_EVO_DRIFT);   // 0 = fresh values, 1 = barely nudge
        const int lock = lockMask();
        const int count = std::max(1, static_cast<int>(std::lround(amt * len)));
        auto blend = [&](int oldV, int freshV) { return static_cast<int>(std::lround(oldV + (freshV - oldV) * (1.0f - keep))); };
        for (int k = 0; k < count; ++k) {
            const int i = rndInt(len);
            Step cur = unpackStep(lane_[i].load(std::memory_order_relaxed));
            const Step f = freshStep();
            if (!(lock & (1 << L_PITCH))) cur.pitch = blend(cur.pitch, f.pitch);
            if (!(lock & (1 << L_VEL))) cur.vel = blend(cur.vel, f.vel);
            if (!(lock & (1 << L_GATE))) cur.gate = blend(cur.gate, f.gate);
            if (!(lock & (1 << L_PROB))) cur.prob = blend(cur.prob, f.prob);
            if (!(lock & (1 << L_RATCH)) && rnd() < 1.0f - keep) cur.ratch = f.ratch;
            if (!(lock & (1 << L_ON)) && rnd() < 1.0f - keep) { cur.on = f.on; cur.tie = f.tie; }
            if (!(lock & (1 << L_MOD))) cur.mod = blend(cur.mod, f.mod);
            lane_[i].store(packStep(cur), std::memory_order_relaxed);
        }
    }

    // ---- scheduler ----
    void pushEv(const Ev& e) { if (nEv_ < static_cast<int>(ev_.size())) ev_[nEv_++] = e; }

    void processEvents() {
        for (int pass = 0; pass < 2; ++pass) {          // offs first, then ons
            const bool wantOn = (pass == 1);
            for (int i = 0; i < nEv_;) {
                if (ev_[i].on == wantOn && ev_[i].t <= time_) {
                    const Ev e = ev_[i];
                    ev_[i] = ev_[--nEv_];
                    if (e.on) { ++snd_[e.note]; h_->arpNoteOn(e.note, e.vel); }
                    else if (snd_[e.note] > 0 && --snd_[e.note] == 0) h_->arpNoteOff(e.note);
                } else {
                    ++i;
                }
            }
        }
    }

    ArpHost* h_;
    float sr_ = 48000.0f;
    std::array<std::atomic<uint64_t>, kLaneSteps> lane_;
    std::atomic<int> playhead_{-1};

    std::array<int, 128> ord_{};
    int cnt_ = 0;
    std::array<int, 512> pool_{};
    std::array<Ev, 512> ev_{};
    int nEv_ = 0;
    std::array<int, 128> snd_{};

    double time_ = 0.0, nominal_ = 0.0, pendingDue_ = 0.0, lastTickTime_ = 0.0;
    float tickLen_ = 0.0f;
    bool hasPending_ = false, extStopped_ = false, strumFlip_ = false;
    int parity_ = 0, tickCount_ = 0;
    int step_ = 0, walker_ = 0, wk_ = 0, cycles_ = 0, shiftAcc_ = 0;
    uint32_t rng_ = 12345u;
};

}  // namespace ob
