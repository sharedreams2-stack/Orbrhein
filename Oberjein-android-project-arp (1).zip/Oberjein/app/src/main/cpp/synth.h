// Oberjein DSP core: 8-voice virtual-analog polysynth (OB-8 style).
// Header-only, allocation-free and lock-free on the audio thread.
#pragma once
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <cstdint>

#include "arp.h"
#include "params.h"

namespace ob {

constexpr int kNumVoices = 8;
constexpr int kCtrlRate = 16;  // control-rate tick, in samples
constexpr float kPi = 3.14159265358979323846f;

inline float fastTanh(float x) {
    x = std::clamp(x, -3.0f, 3.0f);
    const float x2 = x * x;
    return x * (27.0f + x2) / (27.0f + 9.0f * x2);
}

inline float polyBlep(float t, float dt) {
    if (t < dt) { t /= dt; return t + t - t * t - 1.0f; }
    if (t > 1.0f - dt) { t = (t - 1.0f) / dt; return t * t + t + t + 1.0f; }
    return 0.0f;
}

inline float oscSample(float p, float dt, float pw, bool saw, bool pulse) {
    float s = 0.0f;
    if (saw) s += 2.0f * p - 1.0f - polyBlep(p, dt);
    if (pulse) {
        float v = (p < pw ? 1.0f : -1.0f) + polyBlep(p, dt);
        float t2 = p - pw;
        if (t2 < 0.0f) t2 += 1.0f;
        s += v - polyBlep(t2, dt);
    }
    return (saw && pulse) ? s * 0.6f : s;
}

struct EnvCoef { float a, d, s, r; };

struct Env {
    enum Stage { Idle, Attack, Decay, Sustain, Release };
    Stage stage = Idle;
    float level = 0.0f;
    void gateOn() { stage = Attack; }
    void gateOff() { if (stage != Idle) stage = Release; }
    void reset() { stage = Idle; level = 0.0f; }
    float tick(const EnvCoef& c) {
        switch (stage) {
            case Attack:
                level += (1.3f - level) * c.a;
                if (level >= 1.0f) { level = 1.0f; stage = Decay; }
                break;
            case Decay:
                level += (c.s - level) * c.d;
                if (std::fabs(level - c.s) < 1e-4f) { level = c.s; stage = Sustain; }
                break;
            case Sustain: level = c.s; break;
            case Release:
                level -= level * c.r;
                if (level < 1e-4f) { level = 0.0f; stage = Idle; }
                break;
            default: break;
        }
        return level;
    }
};

// 4-pole transistor-ladder style low-pass (CEM3320-ish), 2x oversampled.
struct Ladder {
    float y1 = 0, y2 = 0, y3 = 0, y4 = 0, t1 = 0, t2 = 0, t3 = 0, t4 = 0;
    void reset() { y1 = y2 = y3 = y4 = t1 = t2 = t3 = t4 = 0.0f; }
    float process(float x, float g, float k, bool fourPole) {
        const float in = x * (1.0f + 0.25f * k);
        for (int i = 0; i < 2; ++i) {
            const float u = fastTanh(in - k * y4);
            y1 += g * (u - t1);  t1 = fastTanh(y1);
            y2 += g * (t1 - t2); t2 = fastTanh(y2);
            y3 += g * (t2 - t3); t3 = fastTanh(y3);
            y4 += g * (t3 - t4); t4 = fastTanh(y4);
        }
        return fourPole ? y4 : y2;
    }
};

struct Voice {
    int note = -1;
    bool gate = false;
    uint64_t age = 0;
    float vel = 1.0f;
    float curSemi = 60.0f, tgtSemi = 60.0f, uniCents = 0.0f;
    float p1 = 0.0f, p2 = 0.0f;
    float dt1 = 0.0f, dt2 = 0.0f, pw = 0.5f, g = 0.5f;
    float gl = 0.7f, gr = 0.7f;
    Env fenv, aenv;
    Ladder lp;
    bool active() const { return aenv.stage != Env::Idle; }
};

struct Event { int type; int note; float value; };

class Synth : public ArpHost {
public:
    Synth() : arp_(this) {
        for (int i = 0; i < kNumVoices; ++i) {
            const float pan = (static_cast<float>(i) - 3.5f) / 3.5f * 0.35f;
            voices_[i].gl = std::cos((pan + 1.0f) * kPi / 4.0f);
            voices_[i].gr = std::sin((pan + 1.0f) * kPi / 4.0f);
        }
        for (auto& p : params_) p.store(0.0f);
        for (auto& x : m_) x = 0.0f;
    }

    void setSampleRate(float sr) { sr_ = sr; arp_.setSampleRate(sr); }

    // ---- control API (any thread) ----
    void setParam(int id, float v) {
        if (id >= 0 && id < P_COUNT) params_[id].store(v, std::memory_order_relaxed);
    }
    void noteOn(int note, float vel) { push({0, note, vel}); }
    void noteOff(int note) { push({1, note, 0.0f}); }
    void allNotesOff() { push({2, 0, 0.0f}); }
    void pitchBend(float v) { push({3, 0, v}); }
    void modWheel(float v) { push({8, 0, v}); }
    void clockTick() { push({4, 0, 0.0f}); }
    void transport(int mode) { push({5, mode, 0.0f}); }       // 0 stop, 1 start (reset), 2 continue
    void generate(uint32_t seed) { push({7, static_cast<int>(seed), 0.0f}); }

    // mod matrix: src 0 = none (see kSrc*), dst = any param id
    void setMod(int slot, int src, int dst, float amt) {
        if (slot < 0 || slot >= kModSlots) return;
        mods_[slot].src.store(src, std::memory_order_relaxed);
        mods_[slot].dst.store(dst, std::memory_order_relaxed);
        mods_[slot].amt.store(amt, std::memory_order_relaxed);
    }

    // arp lane (64 stages) + UI feedback
    uint64_t lane(int i) const { return arp_.lane(i); }
    void setLane(int i, uint64_t v) { arp_.setLane(i, v); }
    int playhead() const { return arp_.playhead(); }

    // MIDI out ring (audio thread produces, one JNI thread consumes). Packed: status<<16 | d1<<8 | d2.
    int drainMidiOut(int32_t* buf, int maxN) {
        uint32_t h = outHead_.load(std::memory_order_relaxed);
        const uint32_t t = outTail_.load(std::memory_order_acquire);
        int n = 0;
        while (h != t && n < maxN) { buf[n++] = static_cast<int32_t>(outQ_[h % kOutQ]); ++h; }
        outHead_.store(h, std::memory_order_release);
        return n;
    }

    // ---- audio thread: interleaved stereo float ----
    void render(float* out, int frames) {
        applyModulation();   // m_ must be valid before events (generate/arp read it) on the first buffer
        updateRouting();
        drainEvents();
        for (int n = 0; n < frames; ++n) {
            if (ctrl_ == 0) { updateControl(); ctrl_ = kCtrlRate; }
            --ctrl_;
            volSm_ += (q_.volume - volSm_) * 0.002f;
            float l = 0.0f, r = 0.0f;
            for (auto& v : voices_) {
                if (!v.active()) continue;
                const float s = tickVoice(v);
                l += s * v.gl;
                r += s * v.gr;
            }
            const float g = volSm_ * q_.master;
            out[2 * n] = fastTanh(l * g);
            out[2 * n + 1] = fastTanh(r * g);
        }
    }

private:
    struct Snap {
        bool saw1 = true, pulse1 = false, saw2 = true, pulse2 = false;
        bool sync = false, four = true, unison = false;
        float l1 = 0, l2 = 0, ln = 0, semi2 = 0, det2 = 0, pwBase = 0.5f;
        float cutOct = 0, k = 0, fenvAmt = 0, keytrack = 0;
        float lfoPitch = 0, lfoFilter = 0, lfoPwm = 0;
        float glide = 1.0f, spread = 0, volume = 0, master = 0.4f;
        EnvCoef fe{}, ae{};
    };

    // P() is the modulated value; B() the raw knob value.
    float P(int id) const { return m_[id]; }
    float B(int id) const { return params_[id].load(std::memory_order_relaxed); }

    static float timeOf(float v) { return 0.001f * std::pow(10.0f, 4.0f * v); }  // 1 ms .. 10 s

    EnvCoef coefs(float a, float d, float s, float r) const {
        auto cA = [&](float t) { return 1.0f - std::exp(-1.466f / (std::max(t, 0.0005f) * sr_)); };
        auto cD = [&](float t) { return 1.0f - std::exp(-6.9f / (std::max(t, 0.0005f) * sr_)); };
        return {cA(timeOf(a)), cD(timeOf(d)), s, cD(timeOf(r))};
    }

    void updateControl() {
        applyModulation();
        updateRouting();
        if (arpOn_) arp_.tick(kCtrlRate);
        clockOut();
        Snap& q = q_;
        q.saw1 = P(P_VCO1_SAW) > 0.5f;   q.pulse1 = P(P_VCO1_PULSE) > 0.5f;
        q.saw2 = P(P_VCO2_SAW) > 0.5f;   q.pulse2 = P(P_VCO2_PULSE) > 0.5f;
        q.sync = P(P_SYNC) > 0.5f;       q.four = P(P_POLES) > 0.5f;
        const bool uni = P(P_UNISON) > 0.5f;
        if (uni != q.unison) { q.unison = uni; releaseAll(); }
        q.l1 = P(P_VCO1_LEVEL); q.l2 = P(P_VCO2_LEVEL); q.ln = P(P_NOISE) * 0.5f;
        q.semi2 = std::round((P(P_VCO2_SEMI) - 0.5f) * 24.0f);
        q.det2 = (P(P_VCO2_DETUNE) - 0.5f) * 100.0f;
        q.pwBase = 0.5f - 0.45f * P(P_PWM);
        q.cutOct = P(P_CUTOFF) * 9.81f;
        q.k = P(P_RESO) * 4.2f;
        q.fenvAmt = P(P_FENV_AMT);
        q.keytrack = P(P_KEYTRACK);
        q.lfoPitch = P(P_LFO_PITCH); q.lfoFilter = P(P_LFO_FILTER); q.lfoPwm = P(P_LFO_PWM);
        const float gt = P(P_PORTA) < 0.01f ? 0.0f : 0.01f * std::pow(300.0f, P(P_PORTA));
        q.glide = gt <= 0.0f ? 1.0f : 1.0f - std::exp(-kCtrlRate / (sr_ * gt / 3.0f));
        q.spread = P(P_UNI_DETUNE) * 30.0f;
        q.volume = P(P_VOLUME);
        q.master = q.unison ? 0.4f : 0.7f;
        q.fe = coefs(P(P_F_A), P(P_F_D), P(P_F_S), P(P_F_R));
        q.ae = coefs(P(P_A_A), P(P_A_D), P(P_A_S), P(P_A_R));

        // LFO
        lfoPhase_ += 0.1f * std::pow(300.0f, P(P_LFO_RATE)) * kCtrlRate / sr_;
        if (lfoPhase_ >= 1.0f) { lfoPhase_ -= std::floor(lfoPhase_); shValue_ = noise(); }
        switch (static_cast<int>(std::lround(P(P_LFO_WAVE) * 4.0f))) {
            case 0: lfo_ = std::sin(2.0f * kPi * lfoPhase_); break;
            case 1: lfo_ = 1.0f - 4.0f * std::fabs(lfoPhase_ - 0.5f); break;
            case 2: lfo_ = 2.0f * lfoPhase_ - 1.0f; break;
            case 3: lfo_ = lfoPhase_ < 0.5f ? 1.0f : -1.0f; break;
            default: lfo_ = shValue_; break;
        }
        lfo2Phase_ += 0.1f * std::pow(300.0f, P(P_LFO2_RATE)) * kCtrlRate / sr_;
        if (lfo2Phase_ >= 1.0f) { lfo2Phase_ -= std::floor(lfo2Phase_); sh2Value_ = noise(); }
        switch (static_cast<int>(std::lround(P(P_LFO2_WAVE) * 4.0f))) {
            case 0: lfo2_ = std::sin(2.0f * kPi * lfo2Phase_); break;
            case 1: lfo2_ = 1.0f - 4.0f * std::fabs(lfo2Phase_ - 0.5f); break;
            case 2: lfo2_ = 2.0f * lfo2Phase_ - 1.0f; break;
            case 3: lfo2_ = lfo2Phase_ < 0.5f ? 1.0f : -1.0f; break;
            default: lfo2_ = sh2Value_; break;
        }

        const float maxF = 0.45f * sr_;
        for (auto& v : voices_) {
            if (!v.active()) continue;
            v.curSemi += (v.tgtSemi - v.curSemi) * q.glide;
            const float vib = lfo_ * q.lfoPitch * q.lfoPitch * 2.0f;
            const float base = v.curSemi + bend_ * 2.0f + vib;
            const float f1 = 440.0f * std::exp2((base - 69.0f + v.uniCents / 100.0f) / 12.0f);
            const float f2 = 440.0f * std::exp2((base + q.semi2 - 69.0f + (q.det2 + v.uniCents) / 100.0f) / 12.0f);
            v.dt1 = std::min(f1, maxF) / sr_;
            v.dt2 = std::min(f2, maxF) / sr_;
            v.pw = std::clamp(q.pwBase + 0.4f * lfo_ * q.lfoPwm, 0.05f, 0.95f);
            const float oct = q.cutOct + q.fenvAmt * v.fenv.level * 6.0f
                            + q.keytrack * (base - 60.0f) / 12.0f + q.lfoFilter * lfo_ * 2.0f;
            const float fc = std::clamp(20.0f * std::exp2(oct), 20.0f, 0.49f * sr_);
            v.g = 1.0f - std::exp(-2.0f * kPi * fc / (2.0f * sr_));
        }
    }

    float noise() {
        rng_ ^= rng_ << 13; rng_ ^= rng_ >> 17; rng_ ^= rng_ << 5;
        return static_cast<float>(static_cast<int32_t>(rng_)) / 2147483648.0f;
    }

    float tickVoice(Voice& v) {
        v.fenv.tick(q_.fe);
        const float ae = v.aenv.tick(q_.ae);
        if (!v.active()) { v.lp.reset(); v.note = -1; v.gate = false; return 0.0f; }

        v.p1 += v.dt1;
        const bool wrapped = v.p1 >= 1.0f;
        if (wrapped) v.p1 -= 1.0f;
        if (wrapped && q_.sync) {
            v.p2 = v.p1 * (v.dt2 / std::max(v.dt1, 1e-6f));
            v.p2 -= std::floor(v.p2);
        } else {
            v.p2 += v.dt2;
            if (v.p2 >= 1.0f) v.p2 -= 1.0f;
        }
        const float o1 = oscSample(v.p1, v.dt1, v.pw, q_.saw1, q_.pulse1);
        const float o2 = oscSample(v.p2, v.dt2, v.pw, q_.saw2, q_.pulse2);
        const float mix = (o1 * q_.l1 + o2 * q_.l2 + noise() * q_.ln) * 0.7f;
        const float y = v.lp.process(mix, v.g, q_.k, q_.four);
        return y * ae * (0.3f + 0.7f * v.vel);
    }

    // ---- modulation matrix ----
    void applyModulation() {
        for (int i = 0; i < P_COUNT; ++i) m_[i] = params_[i].load(std::memory_order_relaxed);
        float src[kSrcCount];
        src[kSrcNone] = 0.0f;
        src[kSrcLfo1] = lfo_;
        src[kSrcLfo2] = lfo2_;
        src[kSrcRand] = rndSrc_;
        src[kSrcLane] = laneSrc_;
        src[kSrcWheel] = wheel_.load(std::memory_order_relaxed);
        src[kSrcVel] = lastVel_;
        src[kSrcKey] = std::clamp((lastNote_ - 60) / 36.0f, -1.0f, 1.0f);
        for (int i = 0; i < 4; ++i) src[kSrcMacro1 + i] = params_[P_MACRO1 + i].load(std::memory_order_relaxed);
        for (auto& s : mods_) {
            const int sc = s.src.load(std::memory_order_relaxed);
            const int d = s.dst.load(std::memory_order_relaxed);
            const float a = s.amt.load(std::memory_order_relaxed);
            if (sc <= 0 || sc >= kSrcCount || d < 0 || d >= P_COUNT || a == 0.0f) continue;
            m_[d] = std::clamp(m_[d] + src[sc] * a, 0.0f, 1.0f);
        }
    }

    // ---- ArpHost ----
    float p(int id) const override { return P(id); }
    void arpNoteOn(int note, float vel) override { voiceOn(note, vel); }
    void arpNoteOff(int note) override { voiceOff(note); }
    void arpSources(float r, float l) override { rndSrc_ = r; laneSrc_ = l; }

    // ---- input stage: physical keys -> hold latch -> (arp | voices) ----
    void voiceOn(int note, float vel) {
        lastNote_ = note; lastVel_ = vel;
        handleNoteOn(note, vel);
        midiOut(0x90, note, static_cast<int>(std::lround(std::clamp(vel, 0.0f, 1.0f) * 127.0f)));
    }
    void voiceOff(int note) {
        handleNoteOff(note);
        midiOut(0x80, note, 0);
    }

    void addHeld(int note, float vel) {
        if (held_[note]) return;
        held_[note] = true; velHeld_[note] = vel;
        if (nOrd_ < 128) ord_[nOrd_++] = note;
        if (arpOn_) arp_.add(note, vel); else voiceOn(note, vel);
    }
    void removeHeld(int note) {
        if (!held_[note]) return;
        held_[note] = false;
        int w = 0;
        for (int i = 0; i < nOrd_; ++i) if (ord_[i] != note) ord_[w++] = ord_[i];
        nOrd_ = w;
        if (arpOn_) arp_.remove(note); else voiceOff(note);
    }
    void inNoteOn(int note, float vel) {
        if (note < 0 || note > 127) return;
        down_[note] = true;
        if (holdOn_ && held_[note]) { removeHeld(note); return; }   // hold: pressing again releases
        addHeld(note, vel);
    }
    void inNoteOff(int note) {
        if (note < 0 || note > 127) return;
        down_[note] = false;
        if (!holdOn_) removeHeld(note);
    }
    void panic() {
        arp_.stop();
        arp_.clearNotes();
        for (int n = 0; n < 128; ++n) { held_[n] = false; down_[n] = false; }
        nOrd_ = 0;
        releaseAll();
        midiOut(0xB0, 123, 0);
    }

    // Detects hold / arp on-off edges (raw knob values, not modulated).
    void updateRouting() {
        const bool hold = B(P_ARP_HOLD) > 0.5f;
        if (hold != holdOn_) {
            holdOn_ = hold;
            if (!hold) {                                   // leaving hold: drop latched notes that aren't physically down
                int tmp[128]; int n = nOrd_;
                for (int i = 0; i < n; ++i) tmp[i] = ord_[i];
                for (int i = 0; i < n; ++i) if (!down_[tmp[i]]) removeHeld(tmp[i]);
            }
        }
        const bool on = B(P_ARP_ON) > 0.5f;
        if (on != arpOn_) {
            arpOn_ = on;
            if (on) {
                for (int i = 0; i < nOrd_; ++i) voiceOff(ord_[i]);
                arp_.clearNotes();
                for (int i = 0; i < nOrd_; ++i) arp_.add(ord_[i], velHeld_[ord_[i]]);
                clockAcc_ = 0.0;
                if (B(P_MIDI_CLK_OUT) > 0.5f && B(P_ARP_CLOCK) < 0.5f) midiOut(0xFA, 0, 0);
            } else {
                arp_.stop();
                arp_.clearNotes();
                for (int i = 0; i < nOrd_; ++i) voiceOn(ord_[i], velHeld_[ord_[i]]);
                if (B(P_MIDI_CLK_OUT) > 0.5f && B(P_ARP_CLOCK) < 0.5f) midiOut(0xFC, 0, 0);
            }
        }
    }

    // ---- MIDI out (audio thread only) ----
    void midiOut(int status, int d1, int d2) {
        if (status < 0xF8 && B(P_MIDI_OUT) < 0.5f) return;
        if (status >= 0xF8 && B(P_MIDI_CLK_OUT) < 0.5f) return;
        const int ch = (status < 0xF0) ? std::clamp(static_cast<int>(std::lround(B(P_MIDI_OUT_CH) * 15.0f)), 0, 15) : 0;
        const uint32_t v = (static_cast<uint32_t>((status & 0xF0) == status ? (status | ch) : status) << 16) |
                           (static_cast<uint32_t>(d1 & 0x7F) << 8) | static_cast<uint32_t>(d2 & 0x7F);
        const uint32_t t = outTail_.load(std::memory_order_relaxed);
        if (t - outHead_.load(std::memory_order_acquire) >= kOutQ) return;
        outQ_[t % kOutQ] = v;
        outTail_.store(t + 1, std::memory_order_release);
    }

    // 24 ppqn clock out, only while the arp runs on its internal clock.
    void clockOut() {
        if (!arpOn_ || B(P_MIDI_CLK_OUT) < 0.5f || B(P_ARP_CLOCK) > 0.5f) return;
        const double bpm = 30.0 + 270.0 * B(P_ARP_BPM);
        const double tickLen = sr_ * 60.0 / bpm / 24.0;
        clockAcc_ += kCtrlRate;
        for (int g = 0; g < 4 && clockAcc_ >= tickLen; ++g) { clockAcc_ -= tickLen; midiOut(0xF8, 0, 0); }
    }

    // ---- voice allocation ----
    Voice* pickVoice(int note) {
        for (auto& v : voices_) if (v.note == note && v.active()) return &v;
        for (auto& v : voices_) if (!v.active()) return &v;
        Voice* best = nullptr;
        for (auto& v : voices_) if (!v.gate && (!best || v.age < best->age)) best = &v;
        if (best) return best;
        for (auto& v : voices_) if (!best || v.age < best->age) best = &v;
        return best;
    }

    void handleNoteOn(int note, float vel) {
        if (q_.unison) {
            const bool wasEmpty = stackSize_ == 0;
            removeFromStack(note);
            if (stackSize_ < static_cast<int>(stack_.size())) stack_[stackSize_++] = note;
            for (int i = 0; i < kNumVoices; ++i) {
                Voice& v = voices_[i];
                v.uniCents = (static_cast<float>(i) - 3.5f) / 3.5f * q_.spread;
                v.note = note; v.gate = true; v.vel = vel; v.age = ++counter_;
                v.tgtSemi = static_cast<float>(note);
                if (wasEmpty || !v.active()) {
                    v.curSemi = v.tgtSemi;
                    v.fenv.gateOn(); v.aenv.gateOn();
                }
            }
        } else {
            Voice* v = pickVoice(note);
            if (!v) return;
            const bool was = v->active();
            v->note = note; v->gate = true; v->vel = vel; v->age = ++counter_;
            v->uniCents = 0.0f;
            v->tgtSemi = static_cast<float>(note);
            if (!was) v->curSemi = v->tgtSemi;
            v->fenv.gateOn(); v->aenv.gateOn();
        }
    }

    void handleNoteOff(int note) {
        if (q_.unison) {
            removeFromStack(note);
            if (stackSize_ == 0) { releaseAll(); return; }
            for (auto& v : voices_) { v.note = stack_[stackSize_ - 1]; v.tgtSemi = static_cast<float>(v.note); }
        } else {
            for (auto& v : voices_)
                if (v.note == note && v.gate) { v.gate = false; v.fenv.gateOff(); v.aenv.gateOff(); }
        }
    }

    void releaseAll() {
        stackSize_ = 0;
        for (auto& v : voices_) { v.gate = false; v.fenv.gateOff(); v.aenv.gateOff(); }
    }

    void removeFromStack(int note) {
        int w = 0;
        for (int i = 0; i < stackSize_; ++i) if (stack_[i] != note) stack_[w++] = stack_[i];
        stackSize_ = w;
    }

    // ---- event queue: many producers (spin-locked), one consumer (audio thread) ----
    void push(const Event& e) {
        while (lock_.test_and_set(std::memory_order_acquire)) {}
        const uint32_t t = tail_.load(std::memory_order_relaxed);
        if (t - head_.load(std::memory_order_acquire) < kQueue) {
            queue_[t % kQueue] = e;
            tail_.store(t + 1, std::memory_order_release);
        }
        lock_.clear(std::memory_order_release);
    }

    void drainEvents() {
        uint32_t h = head_.load(std::memory_order_relaxed);
        const uint32_t t = tail_.load(std::memory_order_acquire);
        while (h != t) {
            const Event e = queue_[h % kQueue];
            ++h;
            switch (e.type) {
                case 0: inNoteOn(e.note, e.value); break;
                case 1: inNoteOff(e.note); break;
                case 2: panic(); break;
                case 3: bend_ = e.value; break;
                case 4: if (B(P_ARP_CLOCK) > 0.5f && arpOn_) arp_.extTick(); break;
                case 5:
                    if (B(P_ARP_CLOCK) > 0.5f) { if (e.note == 0) arp_.extStop(); else arp_.extStart(e.note == 1); }
                    break;
                case 7: arp_.generate(static_cast<uint32_t>(e.note)); break;
                case 8: wheel_.store(e.value, std::memory_order_relaxed); break;
            }
        }
        head_.store(h, std::memory_order_release);
    }

    static constexpr uint32_t kQueue = 512;
    std::array<Event, kQueue> queue_{};
    std::atomic<uint32_t> head_{0}, tail_{0};
    std::atomic_flag lock_ = ATOMIC_FLAG_INIT;

    static constexpr int kModSlots = 8;
    static constexpr uint32_t kOutQ = 1024;
    // Mod sources (index = Kotlin MOD_SOURCES)
    enum { kSrcNone = 0, kSrcLfo1, kSrcLfo2, kSrcRand, kSrcLane, kSrcWheel, kSrcVel, kSrcKey, kSrcMacro1, kSrcCount = kSrcMacro1 + 4 };
    struct ModSlot { std::atomic<int> src{0}, dst{0}; std::atomic<float> amt{0.0f}; };
    std::array<ModSlot, kModSlots> mods_;
    std::array<float, P_COUNT> m_{};
    std::atomic<float> wheel_{0.0f};
    float lfo2_ = 0.0f, lfo2Phase_ = 0.0f, sh2Value_ = 0.0f, rndSrc_ = 0.0f, laneSrc_ = 0.0f, lastVel_ = 0.0f;
    int lastNote_ = 60;

    Arp arp_;
    bool holdOn_ = false, arpOn_ = false;
    std::array<bool, 128> down_{}, held_{};
    std::array<float, 128> velHeld_{};
    std::array<int, 128> ord_{};
    int nOrd_ = 0;
    double clockAcc_ = 0.0;
    std::array<uint32_t, kOutQ> outQ_{};
    std::atomic<uint32_t> outHead_{0}, outTail_{0};

    std::array<std::atomic<float>, P_COUNT> params_;
    std::array<Voice, kNumVoices> voices_;
    std::array<int, 16> stack_{};
    int stackSize_ = 0;
    Snap q_;
    float sr_ = 48000.0f, volSm_ = 0.0f, lfoPhase_ = 0.0f, lfo_ = 0.0f, shValue_ = 0.0f, bend_ = 0.0f;
    int ctrl_ = 0;
    uint64_t counter_ = 0;
    uint32_t rng_ = 22222u;
};

}  // namespace ob
