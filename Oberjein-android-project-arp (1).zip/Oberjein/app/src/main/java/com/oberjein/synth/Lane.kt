package com.oberjein.synth

/** The 64-stage lane. Bit layout is identical to packStep() in cpp/arp.h. */
object Lane {
    const val STEPS = 64
    const val PITCH = 0
    const val VEL = 1
    const val GATE = 2
    const val PROB = 3
    const val RATCH = 4
    const val ON = 5
    const val MOD = 6
    const val COUNT = 7
    val NAMES = listOf("Pitch", "Velocity", "Gate", "Prob", "Ratchet", "On/Tie", "Mod")
}

data class Step(
    val pitch: Int = 0,      // scale degrees
    val vel: Int = 100,
    val gate: Int = 100,     // 100 = x1.0
    val prob: Int = 100,
    val ratch: Int = 1,      // 1 = use the global ratchet
    val on: Boolean = true,
    val tie: Boolean = false,
    val mod: Int = 64,       // 64 = 0.0 on the "Lane mod" source
)

private fun c(v: Int, lo: Int, hi: Int): Long = v.coerceIn(lo, hi).toLong()

fun Step.pack(): Long =
    c(pitch + 64, 16, 112) or (c(vel, 0, 127) shl 7) or (c(gate, 0, 127) shl 14) or
        (c(prob, 0, 100) shl 21) or ((c(ratch, 1, 8) - 1) shl 28) or
        ((if (on) 1L else 0L) shl 31) or ((if (tie) 1L else 0L) shl 32) or (c(mod, 0, 127) shl 33)

fun Long.toStep(): Step = Step(
    pitch = (this and 127).toInt() - 64,
    vel = ((this shr 7) and 127).toInt(),
    gate = ((this shr 14) and 127).toInt(),
    prob = minOf(100, ((this shr 21) and 127).toInt()),
    ratch = ((this shr 28) and 7).toInt() + 1,
    on = ((this shr 31) and 1L) != 0L,
    tie = ((this shr 32) and 1L) != 0L,
    mod = ((this shr 33) and 127).toInt(),
)

val DEFAULT_STEP: Long = Step().pack()
