package com.oberjein.synth.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.oberjein.synth.Names
import com.oberjein.synth.P
import com.oberjein.synth.SynthViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SystemTab(vm: SynthViewModel) {
    var name by remember { mutableStateOf(vm.currentName) }
    val exportOne = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.exportTo(uri, false)
    }
    val exportAll = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.exportTo(uri, true)
    }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importFrom(uri)
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 4.dp)) {
        Panel("Patches: every parameter, the 64-stage loop and the mod matrix", Amber, Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f).clip(RoundedCornerShape(4.dp)).background(Track).padding(horizontal = 10.dp, vertical = 9.dp)) {
                    BasicTextField(
                        name, { name = it }, singleLine = true,
                        textStyle = TextStyle(color = Cream, fontSize = 14.sp),
                        cursorBrush = SolidColor(Amber), modifier = Modifier.fillMaxWidth()
                    )
                    if (name.isEmpty()) Text("Patch name", color = Dim, fontSize = 14.sp)
                }
                BarButton("Save", { vm.savePatch(name) }, active = true)
            }
            FlowRow(Modifier.padding(top = 4.dp)) {
                BarButton("Export this patch", { exportOne.launch("oberjein-${vm.currentName}.json") })
                BarButton("Export all patches", { exportAll.launch("oberjein-backup.json") })
                BarButton("Import file", { import.launch(arrayOf("*/*")) })
            }
            if (vm.patchNames.isEmpty()) {
                Text("No saved patches yet.", fontSize = 11.sp, color = Dim, modifier = Modifier.padding(top = 6.dp))
            }
            vm.patchNames.forEach { n ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(n, color = Cream, fontSize = 13.sp, modifier = Modifier.weight(1f).padding(start = 4.dp))
                    BarButton("Load", { vm.loadPatch(n); name = n })
                    BarButton("Delete", { vm.deletePatch(n) })
                }
            }
        }
        Panel("MIDI", Teal, Modifier.fillMaxWidth()) {
            FlowRow(verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center) {
                T(vm, P.MIDI_OUT, "Send notes"); E(vm, P.MIDI_OUT_CH, Names.CHANNELS, "Out channel")
                T(vm, P.MIDI_CLK_OUT, "Send clock"); E(vm, P.MIDI_IN_CH, Names.IN_CHANNELS, "In channel")
            }
            Text(vm.midiStatus, fontSize = 11.sp, color = Cream, modifier = Modifier.padding(top = 4.dp))
            Text(
                "Other apps: pick \"Oberjein Synth\" as MIDI input to play it, or as output to receive its notes and clock " +
                    "(keep Oberjein open). Arp clock = \"MIDI clock\" follows Start/Stop/Clock from the host.\n" +
                    "CC 1 mod wheel, 20-23 macros 1-4, 64 hold, 123 panic.",
                fontSize = 10.sp, color = Dim, modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}
