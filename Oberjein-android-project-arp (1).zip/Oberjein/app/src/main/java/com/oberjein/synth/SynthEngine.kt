package com.oberjein.synth

/** Thin JNI bridge to the C++ synth (cpp/native-lib.cpp). All calls are real-time safe. */
object SynthEngine {
    init { System.loadLibrary("oberjein") }

    external fun nativeStart(): Boolean
    external fun nativeStop()
    external fun nativeSetParam(id: Int, value: Float)
    external fun nativeNoteOn(note: Int, velocity: Float)
    external fun nativeNoteOff(note: Int)
    external fun nativeAllNotesOff()
    external fun nativePitchBend(value: Float)
    external fun nativeModWheel(value: Float)

    // arpeggiator / clock
    external fun nativeClockTick()
    /** 0 = stop, 1 = start (restarts the pattern), 2 = continue. Only used when the arp clock is "MIDI clock". */
    external fun nativeTransport(mode: Int)
    external fun nativeSetStep(index: Int, packed: Long)
    external fun nativeGetSteps(out: LongArray)
    external fun nativeGenerate(seed: Int)
    external fun nativePlayhead(): Int

    // mod matrix
    external fun nativeSetMod(slot: Int, src: Int, dst: Int, amount: Float)

    /** Fills [buf] with queued outgoing MIDI (status shl 16 or d1 shl 8 or d2); returns how many. */
    external fun nativeDrainMidiOut(buf: IntArray): Int
}
