package com.oberjein.synth.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.oberjein.synth.Names
import com.oberjein.synth.P
import com.oberjein.synth.SynthViewModel
import kotlinx.coroutines.delay

private val TABS = listOf("SOUND", "ARP", "MOD", "SYSTEM")

@Composable
fun MainScreen(vm: SynthViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Box(Modifier.fillMaxSize().background(Chassis).safeDrawingPadding()) {
        Column(Modifier.fillMaxSize()) {
            TopBar(vm)
            TabBar(vm, tab) { tab = it }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (tab) {
                    0 -> SoundTab(vm)
                    1 -> ArpTab(vm)
                    2 -> ModTab(vm)
                    else -> SystemTab(vm)
                }
            }
            Keyboard(
                firstNote = vm.firstNote,
                whiteKeys = 14,
                onNoteOn = { n, v -> vm.noteOn(n, v) },
                onNoteOff = { n -> vm.noteOff(n) },
                modifier = Modifier.fillMaxWidth().height(92.dp).padding(horizontal = 4.dp, vertical = 4.dp)
            )
        }
        vm.message?.let { msg ->
            LaunchedEffect(msg) { delay(2500); if (vm.message == msg) vm.message = null }
            Box(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 110.dp)
                    .clip(RoundedCornerShape(8.dp)).background(Walnut).padding(horizontal = 16.dp, vertical = 8.dp)
            ) { Text(msg, color = Cream, fontSize = 13.sp) }
        }
    }
}

@Composable
private fun TabBar(vm: SynthViewModel, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel)) {
        TABS.forEachIndexed { i, t ->
            val arpLive = i == 1 && vm.values[P.ARP_ON] > 0.5f
            Column(
                Modifier.weight(1f).clickable { onSelect(i) }.padding(top = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    if (arpLive) "ARP *" else t, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    color = if (i == selected) Amber else if (arpLive) Mint else Dim
                )
                Box(Modifier.padding(top = 5.dp).fillMaxWidth().height(2.dp).background(if (i == selected) Amber else Panel))
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SoundTab(vm: SynthViewModel) {
    FlowRow(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 4.dp)) {
        Section("Oscillator 1", Amber) {
            Column { T(vm, P.VCO1_SAW, "Saw"); T(vm, P.VCO1_PULSE, "Pulse") }
            K(vm, P.VCO1_LEVEL, "Level")
        }
        Section("Oscillator 2", Amber) {
            Column { T(vm, P.VCO2_SAW, "Saw"); T(vm, P.VCO2_PULSE, "Pulse") }
            K(vm, P.VCO2_LEVEL, "Level")
            K(vm, P.VCO2_SEMI, "Semitone")
            K(vm, P.VCO2_DETUNE, "Detune")
            T(vm, P.SYNC, "Sync")
        }
        Section("Mixer", Amber) {
            K(vm, P.PWM, "Pulse width")
            K(vm, P.NOISE, "Noise")
        }
        Section("Filter", Ember) {
            K(vm, P.CUTOFF, "Cutoff")
            K(vm, P.RESO, "Resonance")
            K(vm, P.FENV_AMT, "Env amount")
            K(vm, P.KEYTRACK, "Key track")
            T(vm, P.POLES, "24 dB")
        }
        Section("Filter envelope", Teal) {
            K(vm, P.F_A, "Attack"); K(vm, P.F_D, "Decay"); K(vm, P.F_S, "Sustain"); K(vm, P.F_R, "Release")
        }
        Section("Amp envelope", Teal) {
            K(vm, P.A_A, "Attack"); K(vm, P.A_D, "Decay"); K(vm, P.A_S, "Sustain"); K(vm, P.A_R, "Release")
        }
        Section("LFO 1", Iris) {
            E(vm, P.LFO_WAVE, Names.LFO_SHAPES, "Shape", width = 70.dp)
            K(vm, P.LFO_RATE, "Rate")
            K(vm, P.LFO_PITCH, "To pitch")
            K(vm, P.LFO_FILTER, "To filter")
            K(vm, P.LFO_PWM, "To width")
        }
        Section("Voices", Cream) {
            K(vm, P.PORTA, "Glide")
            T(vm, P.UNISON, "Unison")
            K(vm, P.UNI_DETUNE, "Spread")
            K(vm, P.VOLUME, "Volume")
        }
    }
}

@Composable
private fun TopBar(vm: SynthViewModel) {
    Row(
        Modifier.fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Walnut, WalnutDark)))
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Oberjein", fontSize = 16.sp, fontWeight = FontWeight.Black, color = Cream)
        Spacer(Modifier.width(10.dp))
        BarButton("<", { vm.loadPreset(vm.presetIndex - 1) })
        Text(
            vm.currentName, Modifier.widthIn(min = 90.dp, max = 140.dp),
            color = Cream, fontSize = 13.sp, textAlign = TextAlign.Center, maxLines = 1
        )
        BarButton(">", { vm.loadPreset(vm.presetIndex + 1) })
        Spacer(Modifier.width(8.dp))
        BarButton("Undo", { vm.undo() }, enabled = vm.canUndo)
        BarButton("Redo", { vm.redo() }, enabled = vm.canRedo)
        Spacer(Modifier.width(8.dp))
        BarButton("HOLD", { vm.toggle(P.ARP_HOLD) }, active = vm.values[P.ARP_HOLD] > 0.5f, accent = Mint)
        BarButton("ARP", { vm.toggle(P.ARP_ON) }, active = vm.values[P.ARP_ON] > 0.5f, accent = Mint)
        Spacer(Modifier.width(8.dp))
        BarButton("-", { vm.shiftOctave(-1) })
        Text("Oct ${vm.octave}", color = Cream, fontSize = 12.sp)
        BarButton("+", { vm.shiftOctave(1) })
        BarButton("Panic", { vm.panic() })
    }
}
