package com.oberjein.synth

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt
import kotlin.random.Random

class SynthViewModel(app: Application) : AndroidViewModel(app) {
    val values = mutableStateListOf<Float>().apply { addAll(DEFAULTS.toList()) }
    val lane = mutableStateListOf<Long>().apply { repeat(Lane.STEPS) { add(DEFAULT_STEP) } }
    val mods = mutableStateListOf<ModSlot>().apply { addAll(defaultMods()) }

    var presetIndex by mutableIntStateOf(0); private set
    var octave by mutableIntStateOf(3); private set
    var currentName by mutableStateOf("Init"); private set
    var playhead by mutableIntStateOf(-1); private set
    var canUndo by mutableStateOf(false); private set
    var canRedo by mutableStateOf(false); private set
    var message by mutableStateOf<String?>(null)
    var midiStatus by mutableStateOf("MIDI: starting...")
    val patchNames = mutableStateListOf<String>()

    private val store = PatchStore(app)
    private val undoStack = ArrayDeque<PatchState>()
    private val redoStack = ArrayDeque<PatchState>()
    private var pending: PatchState? = null
    private var poll: Job? = null

    val firstNote: Int get() = 12 * (octave + 1)

    init {
        store.loadAuto()?.let { applyState(it, push = false) }
        refreshNames()
    }

    // ---------------------------------------------------------------- state / history

    private fun snapshot() = PatchState(currentName, values.toFloatArray(), lane.toLongArray(), mods.toList(), presetIndex, octave)

    private fun applyState(s: PatchState, push: Boolean = true) {
        s.values.forEachIndexed { i, v -> if (i < values.size) values[i] = v }
        s.lane.forEachIndexed { i, v -> if (i < lane.size) lane[i] = v }
        s.mods.forEachIndexed { i, m -> if (i < mods.size) mods[i] = m }
        currentName = s.name
        presetIndex = s.preset
        if (octave != s.octave) { octave = s.octave; SynthEngine.nativeAllNotesOff() }
        if (push) pushAll()
    }

    fun pushAll() {
        values.forEachIndexed { id, v -> SynthEngine.nativeSetParam(id, v) }
        lane.forEachIndexed { i, s -> SynthEngine.nativeSetStep(i, s) }
        mods.forEachIndexed { i, m -> SynthEngine.nativeSetMod(i, m.src, m.dst, m.amt) }
    }

    /** Call before changing anything the user can undo; the first call of a gesture remembers the "before" state. */
    private fun beginEdit() { if (pending == null) pending = snapshot() }

    /** Ends a gesture (knob release, tap...). One gesture = one undo step. */
    fun commit() {
        val before = pending ?: return
        pending = null
        if (before.sameContent(snapshot())) return
        undoStack.addLast(before)
        if (undoStack.size > 200) undoStack.removeFirst()
        redoStack.clear()
        updateFlags()
    }

    fun undo() {
        commit()
        val prev = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(snapshot())
        applyState(prev)
        updateFlags()
    }

    fun redo() {
        commit()
        val next = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(snapshot())
        applyState(next)
        updateFlags()
    }

    private fun updateFlags() { canUndo = undoStack.isNotEmpty(); canRedo = redoStack.isNotEmpty() }

    // ---------------------------------------------------------------- parameters

    /** Knob drags: remember the start, push to the DSP, commit() on release. */
    fun set(id: Int, value: Float) {
        if (values[id] == value) return
        beginEdit()
        values[id] = value
        SynthEngine.nativeSetParam(id, value)
    }

    /** Discrete controls: one tap = one undo step. */
    fun setNow(id: Int, value: Float) { set(id, value); commit() }

    fun toggle(id: Int) = setNow(id, if (values[id] > 0.5f) 0f else 1f)

    /** From MIDI CC (main thread). Not recorded in the undo history. */
    fun setExternal(id: Int, value: Float) {
        values[id] = value
        SynthEngine.nativeSetParam(id, value)
    }

    fun loadPreset(index: Int) {
        val i = Math.floorMod(index, PRESETS.size)
        beginEdit()
        presetIndex = i
        currentName = PRESETS[i].name
        PRESETS[i].values.forEachIndexed { id, v -> if (isSoundParam(id)) values[id] = v }
        pushAll()
        commit()
    }

    fun loadArpPreset(index: Int) {
        val p = ARP_PRESETS.getOrNull(index) ?: return
        beginEdit()
        for (id in P.ARP_MODE..P.EVO_DRIFT) values[id] = DEFAULTS[id]
        p.changes.forEach { (id, v) -> values[id] = v }
        pushAll()
        commit()
    }

    fun shiftOctave(delta: Int) {
        octave = (octave + delta).coerceIn(1, 6)
        SynthEngine.nativeAllNotesOff()
    }

    // ---------------------------------------------------------------- lane (64 stages)

    fun step(i: Int): Step = lane[i].toStep()

    fun setStep(i: Int, s: Step) {
        val packed = s.pack()
        if (lane[i] == packed) return
        beginEdit()
        lane[i] = packed
        SynthEngine.nativeSetStep(i, packed)
    }

    fun resetLane(laneId: Int) {
        beginEdit()
        for (i in 0 until Lane.STEPS) {
            val s = step(i)
            val d = Step()
            val n = when (laneId) {
                Lane.PITCH -> s.copy(pitch = d.pitch)
                Lane.VEL -> s.copy(vel = d.vel)
                Lane.GATE -> s.copy(gate = d.gate)
                Lane.PROB -> s.copy(prob = d.prob)
                Lane.RATCH -> s.copy(ratch = d.ratch)
                Lane.ON -> s.copy(on = d.on, tie = d.tie)
                else -> s.copy(mod = d.mod)
            }
            lane[i] = n.pack(); SynthEngine.nativeSetStep(i, lane[i])
        }
        commit()
    }

    /** Copies stages [0, length) to [length, 2*length): turns a short loop into a longer one to vary. */
    fun duplicateLoop() {
        val len = arpLength()
        beginEdit()
        for (i in len until minOf(Lane.STEPS, len * 2)) { lane[i] = lane[i - len]; SynthEngine.nativeSetStep(i, lane[i]) }
        commit()
    }

    fun arpLength(): Int = 1 + (values[P.ARP_LEN] * 63f).roundToInt()

    /** Re-rolls the lane with the Random controls (locked lanes are kept). The DSP does the work; we then mirror it. */
    fun generate() {
        beginEdit()
        SynthEngine.nativeGenerate(Random.nextInt())
        viewModelScope.launch { delay(90); refreshLane(); commit() }
    }

    private fun refreshLane() {
        val buf = LongArray(Lane.STEPS)
        SynthEngine.nativeGetSteps(buf)
        for (i in 0 until Lane.STEPS) if (lane[i] != buf[i]) lane[i] = buf[i]
    }

    // ---------------------------------------------------------------- mod matrix

    fun setMod(slot: Int, m: ModSlot) {
        if (mods[slot] == m) return
        beginEdit()
        mods[slot] = m
        SynthEngine.nativeSetMod(slot, m.src, m.dst, m.amt)
    }

    fun setModNow(slot: Int, m: ModSlot) { setMod(slot, m); commit() }

    // ---------------------------------------------------------------- patches / backup

    fun refreshNames() { patchNames.clear(); patchNames.addAll(store.names()) }

    fun saveAuto() { store.saveAuto(snapshot()) }

    fun savePatch(name: String) {
        val n = store.clean(name)
        if (n.isEmpty() || !store.save(n, snapshot())) { message = "Could not save"; return }
        currentName = n
        refreshNames()
        message = "Saved \"$n\""
    }

    fun loadPatch(name: String) {
        val s = store.load(name) ?: run { message = "Could not load \"$name\""; return }
        beginEdit()
        applyState(s)
        commit()
        message = "Loaded \"$name\""
    }

    fun deletePatch(name: String) { store.delete(name); refreshNames() }

    /** Writes the current sound (or every saved patch) to a file picked with the system file dialog. */
    fun exportTo(uri: Uri, all: Boolean) {
        val text = if (all) {
            val list = store.names().mapNotNull { store.load(it) }.ifEmpty { listOf(snapshot()) }
            PatchJson.encodeBundle(list)
        } else {
            PatchJson.encode(snapshot())
        }
        viewModelScope.launch(Dispatchers.IO) {
            val ok = runCatching {
                getApplication<Application>().contentResolver.openOutputStream(uri, "wt")!!.use { it.write(text.toByteArray()) }
            }.isSuccess
            withContext(Dispatchers.Main) { message = if (ok) "Backup exported" else "Export failed" }
        }
    }

    fun importFrom(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val text = runCatching {
                getApplication<Application>().contentResolver.openInputStream(uri)!!.use { String(it.readBytes()) }
            }.getOrNull()
            val list = text?.let { PatchJson.decode(it) }
            withContext(Dispatchers.Main) {
                if (list == null) { message = "Not an Oberjein file"; return@withContext }
                if (list.size == 1) {
                    beginEdit(); applyState(list[0]); commit()
                    message = "Imported \"${list[0].name}\""
                } else {
                    list.forEach { store.save(it.name.ifBlank { "Imported" }, it) }
                    refreshNames()
                    message = "Imported ${list.size} patches"
                }
            }
        }
    }

    // ---------------------------------------------------------------- playhead polling (UI only)

    fun startPolling() {
        if (poll?.isActive == true) return
        poll = viewModelScope.launch {
            var n = 0
            while (isActive) {
                val arpOn = values[P.ARP_ON] > 0.5f
                val ph = if (arpOn) SynthEngine.nativePlayhead() else -1
                if (ph != playhead) playhead = ph
                if (arpOn && values[P.EVO_ON] > 0.5f && ++n % 8 == 0) refreshLane()
                delay(33)
            }
        }
    }

    fun stopPolling() { poll?.cancel(); poll = null }

    // ---------------------------------------------------------------- notes (safe from any thread)

    fun noteOn(note: Int, velocity: Float) = SynthEngine.nativeNoteOn(note, velocity)
    fun noteOff(note: Int) = SynthEngine.nativeNoteOff(note)
    fun pitchBend(value: Float) = SynthEngine.nativePitchBend(value)
    fun panic() = SynthEngine.nativeAllNotesOff()
}
