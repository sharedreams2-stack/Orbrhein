package com.oberjein.synth.ui

import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.oberjein.synth.ARP_PRESETS
import com.oberjein.synth.Lane
import com.oberjein.synth.Names
import com.oberjein.synth.P
import com.oberjein.synth.SynthViewModel
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ArpTab(vm: SynthViewModel) {
    var laneSel by rememberSaveable { mutableIntStateOf(0) }
    val lockMask = (vm.values[P.RND_LOCK] * 127f).roundToInt()

    FlowRow(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 4.dp)) {
        Section("Arpeggiator", Mint) {
            T(vm, P.ARP_ON, "ARP"); T(vm, P.ARP_HOLD, "HOLD")
            E(vm, P.ARP_MODE, Names.MODES); E(vm, P.ARP_RATE, Names.RATES, width = 60.dp)
            E(vm, P.ARP_CLOCK, Names.CLOCK, "Clock", width = 90.dp)
        }
        Section("Timing", Mint) {
            K(vm, P.ARP_BPM); K(vm, P.ARP_SWING); K(vm, P.ARP_GATE); K(vm, P.ARP_LEN); K(vm, P.ARP_OCT)
        }
        Section("Notes", Teal) {
            E(vm, P.ARP_CHORD, Names.CHORDS); K(vm, P.ARP_STRUM)
            E(vm, P.ARP_STRUM_DIR, Names.STRUM_DIRS, width = 66.dp)
            K(vm, P.ARP_SHIFT); K(vm, P.ARP_SHIFT_CYCLE)
        }
        Section("Scale", Teal) {
            E(vm, P.ARP_SCALE, Names.SCALES, width = 96.dp); E(vm, P.ARP_ROOT, Names.ROOTS, width = 56.dp)
            T(vm, P.ARP_QUANT, "Snap")
        }
        Section("Feel", Amber) {
            K(vm, P.ARP_PROB); K(vm, P.ARP_RATCH); K(vm, P.ARP_RATCH_PROB); K(vm, P.ARP_VEL); K(vm, P.ARP_HUMAN)
        }
        Panel("Arp presets", Cream) {
            FlowRow { ARP_PRESETS.forEachIndexed { i, p -> Chip(p.name, false, { vm.loadArpPreset(i) }) } }
        }
        Panel("Random generator (fills the 64-stage loop)", Iris, Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BarButton("Generate", { vm.generate() }, active = true, accent = Iris)
                BarButton("Double loop", { vm.duplicateLoop() })
                Text("Lock:", fontSize = 11.sp, color = Dim, modifier = Modifier.padding(start = 8.dp, end = 2.dp))
                FlowRow {
                    Lane.NAMES.forEachIndexed { i, n ->
                        val locked = (lockMask shr i) and 1 == 1
                        Chip(n, locked, { vm.setNow(P.RND_LOCK, (lockMask xor (1 shl i)) / 127f) })
                    }
                }
            }
            FlowRow {
                K(vm, P.RND_DENSITY); K(vm, P.RND_RANGE); K(vm, P.RND_BIAS); K(vm, P.RND_CHORDTONE)
                K(vm, P.RND_VEL); K(vm, P.RND_GATE); K(vm, P.RND_RATCH); K(vm, P.RND_PROB)
                K(vm, P.RND_TIE); K(vm, P.RND_MOD)
            }
        }
        Section("Evolve (same controls as Random)", Ember) {
            T(vm, P.EVO_ON, "Evolve"); K(vm, P.EVO_AMT); K(vm, P.EVO_RATE); K(vm, P.EVO_DRIFT)
        }
        Panel("Stages: ${vm.arpLength()} in loop", Sky, Modifier.fillMaxWidth()) {
            FlowRow(verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center) {
                Lane.NAMES.forEachIndexed { i, n -> Chip(n, laneSel == i, { laneSel = i }) }
                BarButton("Reset lane", { vm.resetLane(laneSel) })
            }
            LaneEditor(vm, laneSel, Modifier.fillMaxWidth().height(132.dp).padding(top = 4.dp))
            if (laneSel == Lane.ON) {
                Text("Tap or drag: Off > On > Tie (tie = legato into next stage)", fontSize = 10.sp, color = Dim)
            }
        }
    }
}
